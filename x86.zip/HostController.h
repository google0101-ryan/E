#pragma once

#include "Bus.h"


// This class is just for show
class HostController : Device
{
	HostController(Bus* bus) : Device(1) // We don't need any mem, really
	{
		name = (char*)"Intel Corporation 440FX";
		bus->register_device(1, this);
	}
	uint8_t read(uint32_t address) { return 0; }
};

