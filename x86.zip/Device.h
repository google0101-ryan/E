#pragma once

#include <stdint.h>
#include <malloc.h>

class Device
{
public:
	Device(uint32_t mem_size)
	{
		mem = (uint8_t*)malloc(mem_size);
		name = (char*)malloc(30);
	}
	virtual void write(uint32_t addr, uint8_t data) {}
	virtual uint8_t read(uint32_t addr) { return 0; }
	uint8_t* mem;
	char *name; // For debugging
};