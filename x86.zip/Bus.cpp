#include "Bus.h"
#include <cstdio>

void Bus::write(uint32_t address, uint8_t data)
{
	for (int i = 0; i < cur_device; i++)
	{
		if (devices[i]->from <= address && devices[i]->to >= address)
		{
			devices[i]->device->write(address - devices[i]->from, data);
			return;
		}
	}

	ram->write(address, data);
}

void Bus::enumerate_devices()
{
	MMIO* device;
	for (int i = 0; i < cur_device; i++)
	{
		device = devices[i];
		printf("Device %s: from 0x%0x to 0x%0x\n", device->device->name, device->from, device->to);
		for (int j = 0; j < 0x10; j++)
		{
			printf("0x%0x: 0x%0x\n", j + device->from, device->device->read(j));
		}
	}
	printf("Device Intel(R) Pentium(R) w/ MMX Technology\n");
}

void Bus::register_mmio(uint32_t from, uint32_t to, Device* device)
{
	MMIO* new_device;
	new_device = (MMIO*)malloc(sizeof(MMIO));
	new_device->device = device;
	new_device->from = from;
	new_device->to = to;
	devices[cur_device] = new_device;
	cur_device++;
}

void Bus::register_device(uint32_t id, Device* device)
{
	NormDevice* normdevice = (NormDevice*)malloc(sizeof(NormDevice));
	normdevice->device = device;
	normdevice->id = id;
	norm_devices[cur_norm_device] = normdevice;
	cur_norm_device++;
}

uint8_t Bus::read(uint32_t address)
{
	for (int i = 0; i < cur_device; i++)
	{
		if (devices[i]->from <= address && devices[i]->to >= address)
		{
			return devices[i]->device->read(address - devices[i]->from);
		}
	}

	ram->read(address);
}