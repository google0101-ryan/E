#include "VGA.h"
#include <Windows.h>

void VGA::write(uint32_t address, uint8_t data)
{
	mem[address] = data;
}

uint8_t VGA::read(uint32_t address)
{
	return mem[address];
}

SDL_Window* window;
SDL_Renderer* renderer;
SDL_Texture* texture, * text;
TTF_Font* font;

void* __cdecl UpdateScreen(void* ptr)
{
	while (1)
	{
		SDL_Rect dest;
		VGA* vga = (VGA*)ptr;
		SDL_Color foreground = { 0, 0, 0 };
		SDL_Surface* text_surf = TTF_RenderText_Solid(font, (const char*)vga->mem, foreground);
		text = SDL_CreateTextureFromSurface(renderer, text_surf);
		dest.x = 0;
		dest.y = 0;
		dest.w = 80;
		dest.h = 25;
		SDL_RenderCopy(renderer, text, NULL, &dest);
		SDL_DestroyTexture(text);
		SDL_FreeSurface(text_surf);
		SDL_RenderPresent(renderer);
	}
}
void setup(VGA* vga)
{
	pthread_t thread;
	pthread_create(&thread, NULL, UpdateScreen, vga);

	SDL_Init(SDL_INIT_EVERYTHING);
	TTF_Init();
	window = SDL_CreateWindow("Intel(R) Pentium(R) with MMX Technology, 512Mb RAM", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 80, 25, SDL_WINDOW_SHOWN);
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
	font = TTF_OpenFont("VGA.ttf", 12);
	SDL_SetWindowResizable(window, SDL_FALSE);
}