#include "ROM.h"
#include <cstdio>
#include <cstdlib>

void ROM::write(uint32_t address, uint8_t data)
{
	printf("ERROR: Attempted writing to ROM!\n");
	exit(-1);
}

uint8_t ROM::read(uint32_t address)
{
	return mem[address];
}
