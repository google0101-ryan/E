#include <stdint.h>
#include <stdio.h>
#include "Pentium.h"

void hlt(Pentium* cpu)
{
	cpu->halted = true;
	cpu->eip++;
}

void cli(Pentium* cpu)
{
	cpu->eip++;
}