#include "Pentium.h"
#include <cstdio>
#include <cstdlib>

void Pentium::reset()
{
	a20 = isPe = isPg = halted = false;
	ebp.ebp = esp.esp = esi.esi = edi.edi = 0;
	eax.eax = ebx.ebx = ecx.ecx = edx.edx = 0;
	eip = 0x7c00;
	cs = 0x0;
	ds = es = fs = gs = ss = 0;
	cr0 = cr4 = 0;
}

void Pentium::clock()
{
	uint32_t physaddr = getPhysAddr(cs, eip);
	uint8_t instr = bus->read(physaddr);
	printf("0x%x\n", instr);
	if (instructions[instr] != NULL)
	{
		instr_func_t *exec = instructions[instr];
		exec(this);
	}
	else
	{
		printf("ERROR: Opcode not implemented 0x%x\n", instr);
		exit(-2);
	}
}

void Pentium::run()
{
	while (!halted)
	{
		clock();
	}
}

uint32_t Pentium::getPhysAddr(uint16_t segment, uint32_t addr)
{
	if (!isPe)
	{
		uint32_t ret = (segment << 4) + addr;
		return ret;
	}
}

void Pentium::enumIO()
{
	for (int i = 0; i < io->cur_io; i++)
	{
		printf("IO device %s, with ports ", io->io[i]->name);
		for (int j = 0; j < 19; j++)
		{
			printf("0x%x, ", io->io[i]->ownedports[j]);
		}
		printf("0x%x\n", io->io[i]->ownedports[19]);
	}
}
