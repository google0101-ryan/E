#include "Bus.h"
#include "VGA.h"
#include "ROM.h"
#include "Pentium.h"
#include "IDE.h"

void main()
{
	RAM* ram = new RAM();
	Bus* bus = new Bus(ram);
	VGA* vga = new VGA(bus);
	ROM* rom = new ROM(bus);
	Pentium* cpu = new Pentium(bus);
	IDE* drive = new IDE(cpu, true);
	
	FILE* f = fopen("boot", "rb");
	if (f == NULL)
	{
		printf("PANIC: File \'boot\' not found!\n");
		exit(-1);
	}
	uint32_t bin_size;
	fseek(f, 0, SEEK_END);
	bin_size = ftell(f);
	fseek(f, 0, SEEK_SET);

	uint8_t* bin = (uint8_t*)malloc(bin_size);
	fread(bin, 1, bin_size, f);

	memcpy(ram->mem + 0x7c00, bin, 512);

	bus->write(0xb8000, 0x10);
	bus->enumerate_devices();
	cpu->enumIO();
	cpu->run();
}