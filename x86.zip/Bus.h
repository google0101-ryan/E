#pragma once

#include <stdint.h>
#include "Device.h"
#include "RAM.h"

struct MMIO
{
	uint32_t from;
	uint32_t to;
	Device* device;
};

struct NormDevice
{
	uint32_t id;
	Device* device;
};

class Bus
{
	MMIO* devices[32];
	NormDevice* norm_devices[32];
	uint8_t cur_device, cur_norm_device;
	RAM* ram;
public:
	Bus(RAM* m_ram) : ram(m_ram) {}
	uint8_t read(uint32_t address);
	void write(uint32_t address, uint8_t data);
	void enumerate_devices();
	void register_mmio(uint32_t from, uint32_t to, Device *device);
	void register_device(uint32_t id, Device* device);
};

