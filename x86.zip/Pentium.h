#pragma once

#include "Bus.h"
#include <stdint.h>
#include <memory.h>

class Pentium;

void hlt(Pentium*);
void cli(Pentium*);

class MappedIO
{
public:
	MappedIO(uint32_t* ownports) 
	{
		ownedports = ownports;
	}
	virtual uint8_t read8(uint32_t port) { return 0; }
	virtual void write8(uint32_t port, uint8_t data) {}
	virtual uint32_t read32(uint32_t address) { return 0; }
	uint32_t* ownedports;
	char* name;
};

class IO
{
public:
	MappedIO* io[20];
	uint8_t read8(uint32_t address)
	{
		for (int i = 0; i < 20; i++)
		{
			for (int j = 0; j < 20; j++)
			{
				if (io[i]->ownedports[j] == address)
				{
					io[i]->read8(address);
					break;
				}
			}
		}
	}
	void write8(uint32_t address, uint8_t data)
	{
		for (int i = 0; i < 20; i++)
		{
			for (int j = 0; j < 20; j++)
			{
				if (io[i]->ownedports[j] == address)
				{
					io[i]->write8(address, data);
					break;
				}
			}
		}
	}
	uint32_t cur_io;

	void register_io_device(MappedIO* newio)
	{
		io[cur_io] = newio;
		cur_io++;
	}
};

class Pentium
{
public:
	typedef void instr_func_t(Pentium*);
	instr_func_t* instructions[256];
	bool halted, a20, isPe, isPg;
	Bus* bus;
	uint32_t eip;
	union
	{
		union
		{
			struct
			{
				uint8_t ah;
				uint8_t al;
			};
			uint16_t ax;
		};
		uint32_t eax;
	} eax;
	union
	{
		union
		{
			struct
			{
				uint8_t bh;
				uint8_t bl;
			};
			uint16_t bx;
		};
		uint32_t ebx;
	} ebx;
	union
	{
		union
		{
			struct
			{
				uint8_t ch;
				uint8_t cl;
			};
			uint16_t cx;
		};
		uint32_t ecx;
	} ecx;
	union
	{
		union
		{
			struct
			{
				uint8_t dh;
				uint8_t dl;
			};
			uint16_t dx;
		};
		uint32_t edx;
	} edx;
	union
	{
		uint16_t si;
		uint32_t esi;
	} esi;

	union
	{
		uint16_t di;
		uint32_t edi;
	} edi;

	union
	{
		uint16_t sp;
		uint32_t esp;
	} esp;

	union
	{
		uint16_t bp;
		uint32_t ebp;
	} ebp;
	uint16_t cs, ds, es, fs, gs, ss;
	uint16_t cr0, cr4;
	IO* io;
public:
	Pentium(Bus* bus) : bus(bus) 
	{
		memset(instructions, 0, 256);
		instructions[0xf4] = hlt;
		instructions[0xFA] = cli;
		a20 = isPe = isPg = halted = false;
		ebp.ebp = esp.esp = esi.esi = edi.edi = 0;
		eax.eax = ebx.ebx = ecx.ecx = edx.edx = 0;
		eip = 0x7c00;
		cs = 0x0;
		ds = es = fs = gs = ss = 0;
		cr0 = cr4 = 0;
		io = new IO();
	}
	void reset();
	void clock();
	void run();
	void enumIO();
	uint32_t getPhysAddr(uint16_t segment, uint32_t addr);
};

