#pragma once
#include <cstdint>
class RAM
{
public:
	uint8_t mem[1024 * 1024 * 512];
	uint8_t read(uint32_t address);
	void write(uint32_t address, uint8_t data);
};

