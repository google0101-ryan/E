#include "RAM.h"

uint8_t RAM::read(uint32_t address)
{
    return mem[address];
}

void RAM::write(uint32_t address, uint8_t data)
{
    mem[address] = data;
}
