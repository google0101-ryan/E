#pragma once

#include <stdint.h>
#include "Bus.h"
#include "Device.h"
#include <memory.h>

class ROM : public Device
{
public:
	ROM(Bus* bus) : Device(1024 * 8)
	{
		memset(mem, 0, 1024 * 8);
		name = (char*)"8Kb BIOS ROM Chip";
		bus->register_mmio(0x10FEFF, 0x10FEFF + 1024 * 8, this);
		mem[0] = 0xf4;
	}
	void write(uint32_t address, uint8_t data);
	uint8_t read(uint32_t address);
};

