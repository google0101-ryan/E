#pragma once

#include "Bus.h"
#include <memory.h>
#include <pthread.h>
#define SDL_MAIN_HANDLED
#include <SDL.h>
#include <SDL_ttf.h>

extern class VGA;

void setup(VGA* vga);
void* __cdecl UpdateScreen(void* ptr);

class VGA : public Device
{
public:
	VGA(Bus* bus) : Device(80 * 25) 
	{
		memset(mem, ' ', 80 * 25);
		name = (char*)"VGA Graphics";
		bus->register_mmio(0xb8000, 0xb8000 + (80 * 25), this);
		setup(this);
	}
	void write(uint32_t address, uint8_t data);
	uint8_t read(uint32_t address);
private:
};
