#pragma once

#include "Pentium.h"
#include <cstdio>
#include <cstdlib>

uint32_t io1[20] = { 0x1f0, 0x1f1, 0x1f2, 0x1f3, 0x1f4, 0x1f5, 0x1f6, 0x1f7, 0x3f6 };
uint32_t io2[20] = { 0x170, 0x171, 0x172, 0x173, 0x174, 0x175, 0x176, 0x177, 0x376 };

class IDE : MappedIO
{
	uint8_t drive[1024 * 1024 * 500];
	uint16_t data;
	uint8_t sec_count;
	uint8_t lba_low;
	uint8_t lba_mid;
	uint8_t lba_high;
	uint8_t drive_head;
	uint8_t status_command;
	/* Utility */
	uint32_t head_index;
public:
	IDE(Pentium* pentium, bool isMaster) : MappedIO(isMaster ? io1 : io2)
	{
		pentium->io->register_io_device(this);
		name = (char*)"IDE Hard Disk Controller";
		memset(drive, 0, 1024 * 1024 * 500);
	}
private:
	void write8(uint32_t addr, uint8_t data)
	{
		switch (addr)
		{
		case 0x1f2:
			sec_count = data;
			break;
		case 0x1f3:
			lba_low = data;
			break;
		case 0x1f4:
			lba_mid = data;
			break;
		case 0x1f5:
			lba_high = data;
			break;
		case 0x1f6:
			drive_head = data;
			break;
		case 0x1f7:
			status_command = data;
			break;
		default:
			printf("Unimplemented IDE port command outb 0x%x\n", addr);
			exit(-1);
			break;
		}
	}

	uint8_t disk_read8()
	{
		uint8_t data = drive[head_index];
		head_index += 1;
		return data;
	}

	uint32_t disk_read32()
	{
		int i;
		uint32_t data = 0;
		for (i = 0; i < 4; i++)
		{
			data |= disk_read8() << (8 * i);
		}
		return data;
	}

	uint8_t read8(uint32_t address)
	{
		switch (address)
		{
		case 0x1f7:
			return status_command;
		default:
			printf("Unimplemented IDE port command 0x%x\n", address);
			exit(-1);
			break;
		}
	}

	uint32_t read32(uint32_t address)
	{
		switch (address)
		{
		case 0x1f0:
			return read32(address);
			break;
		default:
			printf("IN32 IDE disk command 0x%x not implemented\n", address);
			exit(-1);
			break;
		}
	}

	void set_head_index()
	{
		uint32_t head = 0 | lba_low | (lba_mid << 8) | (lba_high << 16) |
			((drive_head & 0x0F) << 24);
		head_index = head * 512;
	}
};